const mongoose = require('mongoose');

const TaskSchema = new mongoose.Schema({
  user: {
    type: String,
    required: true
  },
  name: {
    type: String,
    required: true
  },
  description: {
    type: String,
    required: true
  },
  dueDate: {
    type: Date,
    required: true
  }
});

module.exports = mongoose.model('Task', TaskSchema);