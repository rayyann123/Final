const express = require('express');
const router = express.Router();
const Task = require('../models/Task');

// Middleware for checking hardcoded credentials
const authMiddleware = (req, res, next) => {
  const { username, password } = req.headers;
  if (username === 'admin' && password === 'admin123') {
    req.user = 'admin';
    next();
  } else {
    res.status(401).json({ message: 'Unauthorized' });
  }
};

// Get all tasks for the logged-in user
router.get('/', authMiddleware, async (req, res) => {
  const tasks = await Task.find({ user: req.user });
  res.json(tasks);
});

// Create a new task
router.post('/', authMiddleware, async (req, res) => {
  const { name, description, dueDate } = req.body;
  const newTask = new Task({ user: req.user, name, description, dueDate });
  await newTask.save();
  res.status(201).json(newTask);
});

// Update a task
router.put('/:id', authMiddleware, async (req, res) => {
  const { name, description, dueDate } = req.body;
  const updatedTask = await Task.findOneAndUpdate(
    { _id: req.params.id, user: req.user },
    { name, description, dueDate },
    { new: true }
  );
  if (updatedTask) {
    res.json(updatedTask);
  } else {
    res.status(404).json({ message: 'Task not found' });
  }
});

// Delete a task
router.delete('/:id', authMiddleware, async (req, res) => {
  const deletedTask = await Task.findOneAndDelete({ _id: req.params.id, user: req.user });
  if (deletedTask) {
    res.json({ message: 'Task deleted' });
  } else {
    res.status(404).json({ message: 'Task not found' });
  }
});

module.exports = router;